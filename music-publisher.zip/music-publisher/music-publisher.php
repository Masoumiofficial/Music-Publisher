<?php
/**
 * Plugin Name: Sajad Music Publisher
 * Plugin URI:  https://sajadmasoumi.com
 * Description: پنل حرفه‌ای ارسال پست موزیک، ریمیکس، نوحه، موزیک ویدیو، آلبوم و لیچ فایل برای سایت‌های موزیک وردپرسی
 * Version:     1.0.0
 * Author:      سجاد معصومی
 * Author URI:  https://sajadmasoumi.com
 * License:     GPL-2.0+
 * Text Domain: sajad-music-publisher
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'SMP_VERSION', '1.0.0' );
define( 'SMP_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'SMP_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

require_once SMP_PLUGIN_DIR . 'includes/class-smp-settings.php';
require_once SMP_PLUGIN_DIR . 'includes/class-smp-admin-pages.php';
require_once SMP_PLUGIN_DIR . 'includes/class-smp-post-handler.php';

function smp_init() {
    $settings = new SMP_Settings();
    $settings->init();

    $admin = new SMP_Admin_Pages();
    $admin->init();

    $handler = new SMP_Post_Handler();
    $handler->init();
}
add_action( 'plugins_loaded', 'smp_init' );
