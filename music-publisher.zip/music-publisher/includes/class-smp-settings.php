<?php
if ( ! defined( 'ABSPATH' ) ) exit;

class SMP_Settings {

    const ALL_KEYS = array(
        'urldlhost','urlfunction_music','urlfunction_remix','urlfunction_video',
        'urlfunction_album','urlfunction_nohe','urlfunction_leech',
        'namesite','namesite2','urlsite',
        'cat_music','cat_remix','cat_nohe','cat_video','cat_album',
    );

    public function init() {
        add_action( 'admin_menu', array( $this, 'add_settings_page' ) );
        add_action( 'admin_init', array( $this, 'register_settings' ) );
        add_action( 'admin_enqueue_scripts', array( $this, 'enqueue' ) );
    }

    public function enqueue( $hook ) {
        if ( strpos( $hook, 'smp' ) === false ) return;
        wp_enqueue_style( 'smp-admin', SMP_PLUGIN_URL . 'assets/css/admin.css', array(), SMP_VERSION );
        wp_enqueue_script( 'smp-admin', SMP_PLUGIN_URL . 'assets/js/admin.js', array(), SMP_VERSION, true );
    }

    public function add_settings_page() {
        add_submenu_page(
            'smp-dashboard',
            'تنظیمات',
            'تنظیمات',
            'manage_options',
            'smp-settings',
            array( $this, 'render_settings_page' )
        );
    }

    public function register_settings() {
        register_setting( 'smp_options_group', 'smp_options', array( $this, 'sanitize' ) );
    }

    public function sanitize( $input ) {
        $clean = array();
        foreach ( self::ALL_KEYS as $k ) {
            $clean[ $k ] = isset( $input[ $k ] ) ? sanitize_text_field( $input[ $k ] ) : '';
        }
        return $clean;
    }

    private function row( $opts, $key, $label, $placeholder = '' ) {
        $val = isset( $opts[ $key ] ) ? esc_attr( $opts[ $key ] ) : '';
        echo '<tr><th>' . esc_html( $label ) . '</th><td><input type="text" name="smp_options[' . esc_attr( $key ) . ']" value="' . $val . '" placeholder="' . esc_attr( $placeholder ) . '"></td></tr>';
    }

    public function render_settings_page() {
        $opts = get_option( 'smp_options', array() );
        ?>
        <div class="smp-wrap" dir="rtl" data-theme="dark">
            <div class="smp-header">
                <div class="smp-header-icon">⚙️</div>
                <div class="smp-header-text"><h1>تنظیمات افزونه</h1><p>پیکربندی هاست دانلود، دسته‌بندی‌ها و اطلاعات سایت</p></div>
                <div class="smp-theme-toggle" id="smp-theme-toggle" title="تغییر حالت روز/شب">
                    <span class="smp-theme-icon-light">☀️</span>
                    <span class="smp-theme-icon-dark">🌙</span>
                </div>
            </div>

            <?php
            $tabs = array(
                'smp-dashboard' => '🎵 تک آهنگ', 'smp-remix' => '🎛️ ریمیکس', 'smp-nohe' => '🕌 نوحه',
                'smp-video' => '🎬 موزیک ویدیو', 'smp-album' => '💿 آلبوم', 'smp-leech' => '⬇️ لیچ', 'smp-settings' => '⚙️ تنظیمات',
            );
            echo '<div class="smp-tabs">';
            foreach ( $tabs as $slug => $label ) {
                $cls = ( $slug === 'smp-settings' ) ? 'smp-tab active' : 'smp-tab';
                echo '<a href="' . esc_url( admin_url( 'admin.php?page=' . $slug ) ) . '" class="' . $cls . '"><span class="tab-dot"></span>' . esc_html( $label ) . '</a>';
            }
            echo '</div>';

            if ( isset( $_GET['settings-updated'] ) ) {
                echo '<div class="smp-notice success">✅ تنظیمات با موفقیت ذخیره شد.</div>';
            }
            ?>

            <form method="post" action="options.php">
                <?php settings_fields( 'smp_options_group' ); ?>

                <div class="smp-card">
                    <div class="smp-card-title">🌐 هاست دانلود</div>
                    <table class="smp-settings-table">
                        <?php
                        $this->row( $opts, 'urldlhost', 'آدرس هاست دانلود', 'https://dl.example.ir' );
                        $this->row( $opts, 'urlfunction_music', 'آدرس curl-music.php', 'https://dl.example.ir/curl-music.php' );
                        $this->row( $opts, 'urlfunction_remix', 'آدرس curl-remix.php', 'https://dl.example.ir/curl-remix.php' );
                        $this->row( $opts, 'urlfunction_video', 'آدرس curl-video.php', 'https://dl.example.ir/curl-video.php' );
                        $this->row( $opts, 'urlfunction_album', 'آدرس curl-album.php', 'https://dl.example.ir/curl-album.php' );
                        $this->row( $opts, 'urlfunction_nohe',  'آدرس curl-nohe.php',  'https://dl.example.ir/curl-nohe.php' );
                        $this->row( $opts, 'urlfunction_leech', 'آدرس curl-leech.php', 'https://dl.example.ir/curl-leech.php' );
                        ?>
                    </table>
                    <p class="smp-hint">💡 فقط آدرس‌های وارد شده در همین فرم مجاز به دریافت داده از افزونه هستند (محافظت در برابر SSRF).</p>
                </div>

                <div class="smp-card">
                    <div class="smp-card-title">🏷️ اطلاعات سایت</div>
                    <table class="smp-settings-table">
                        <?php
                        $this->row( $opts, 'namesite',  'نام سایت (فارسی)' );
                        $this->row( $opts, 'namesite2', 'نام سایت (انگلیسی)' );
                        $this->row( $opts, 'urlsite',   'دامنه سایت (بدون https://)', 'example.ir' );
                        ?>
                    </table>
                </div>

                <div class="smp-card">
                    <div class="smp-card-title">📁 دسته‌بندی‌ها (Category ID)</div>
                    <table class="smp-settings-table">
                        <?php
                        $this->row( $opts, 'cat_music', 'دسته‌بندی تک آهنگ', 'مثال: 10,12' );
                        $this->row( $opts, 'cat_remix', 'دسته‌بندی ریمیکس', 'مثال: 10,13' );
                        $this->row( $opts, 'cat_nohe',  'دسته‌بندی نوحه',   'مثال: 10,14' );
                        $this->row( $opts, 'cat_video', 'دسته‌بندی موزیک ویدیو', 'مثال: 10,15' );
                        $this->row( $opts, 'cat_album', 'دسته‌بندی آلبوم', 'مثال: 5431,2' );
                        ?>
                    </table>
                    <p class="smp-hint">💡 شناسه دسته‌ها را از منوی «نوشته‌ها ← دسته‌ها» بردارید؛ چند شناسه را با ویرگول جدا کنید.</p>
                </div>

                <div class="smp-submit-row">
                    <?php submit_button( '💾 ذخیره تنظیمات', 'primary', 'submit', false, array( 'class' => 'smp-btn smp-btn-primary' ) ); ?>
                </div>
            </form>

            <div class="smp-card smp-about-card">
                <div class="smp-card-title">👨‍💻 درباره افزونه</div>
                <p class="smp-about-text">
                    افزونه <strong class="smp-accent">Sajad Music Publisher</strong> — نسخه <?php echo esc_html( SMP_VERSION ); ?><br>
                    طراحی و توسعه توسط <a href="https://sajadmasoumi.com" target="_blank" rel="noopener" class="smp-accent-link">سجاد معصومی</a>
                </p>
            </div>
        </div>
        <?php
    }

    public static function get( $key, $default = '' ) {
        $options = get_option( 'smp_options', array() );
        return isset( $options[ $key ] ) && $options[ $key ] !== '' ? $options[ $key ] : $default;
    }
}
