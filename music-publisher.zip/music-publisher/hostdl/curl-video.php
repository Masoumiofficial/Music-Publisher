<?php
require_once 'jdf.php';
$dir = jdate_win('Y/m/d', time());
$dir_file = "video/{$dir}";
if ( ! file_exists($dir_file))
    mkdir($dir_file, 0755, true);
    set_time_limit(0);
$enname = $_POST['artist_en'];
$entrack = $_POST['song_en'];
$link1080 = $_POST['hs_video1080p'];
$link720 = $_POST['hs_video720p'];
$link480 = $_POST['hs_video480p'];

$Trackname = "{$enname} - {$entrack}";
$GenerateTrackLink1080 = $_SERVER['DOCUMENT_ROOT'] . "/$dir_file/{$Trackname} (1080p).mp4";
$GenerateTrackLink720 = $_SERVER['DOCUMENT_ROOT'] . "/$dir_file/{$Trackname} (720p).mp4";
$GenerateTrackLink480 = $_SERVER['DOCUMENT_ROOT'] . "/$dir_file/{$Trackname} (480p).mp4";
function Download($url, $saveto){$content = file_get_contents($url);file_put_contents($saveto, $content);}

if (!empty($link1080)) Download($link1080, $GenerateTrackLink1080);
if (!empty($link720)) Download($link720, $GenerateTrackLink720);
if (!empty($link480)) Download($link480, $GenerateTrackLink480);

?>