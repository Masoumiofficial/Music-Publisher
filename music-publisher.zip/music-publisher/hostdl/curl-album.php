<?php
ini_set("max_execution_time", 900);
ini_set('memory_limit','1024M');
require_once 'jdf.php'; 
$jdate = jdate_win('Y/m/', time());
$artist_en = $_POST['artist_en'];
$song_en = $_POST['song_en'];
$cover = $_POST['cover'];
$src = trim($cover);
$AlbumName = "{$artist_en} - {$song_en}";

for($i=1;$i<=15;$i++) {
	if(!empty($_POST['hs_trackname_'.$i.''])) {
			$hs_trackname_{$i} = $_POST['hs_trackname_'.$i.''];
		}
		
		if(!empty($_POST['hs_link_128_'.$i.''])) {
			$hs_link_128_{$i} = $_POST['hs_link_128_'.$i.''];
		}
		
		if(!empty($_POST['hs_link_320_'.$i.''])) {
			$hs_link_320_{$i} = $_POST['hs_link_320_'.$i.''];
		}
}

$dir128 = "album/{$jdate}/{$AlbumName} [128]";
$dir320 = "album/{$jdate}/{$AlbumName}";
if ( ! file_exists($dir128)) mkdir($dir128, 0755, true);
if ( ! file_exists($dir320)) mkdir($dir320, 0755, true);

for($i=1;$i<=15;$i++) {
if(!empty($_POST['hs_trackname_'.$i.''])) {
	if ( $i<=9 ) {
		$num = "0".$i;
	$GenerateTrackLink_320_{$i} = $_SERVER['DOCUMENT_ROOT'] . "/{$dir320}/{$num}. {$artist_en} - {$hs_trackname_{$i}}.mp3";
	$GenerateTrackLink_128_{$i} = $_SERVER['DOCUMENT_ROOT'] . "/{$dir128}/{$num}. {$artist_en} - {$hs_trackname_{$i}} [128].mp3";
} else {
	$GenerateTrackLink_320_{$i} = $_SERVER['DOCUMENT_ROOT'] . "/{$dir320}/{$i}. {$artist_en} - {$hs_trackname_{$i}}.mp3";
	$GenerateTrackLink_128_{$i} = $_SERVER['DOCUMENT_ROOT'] . "/{$dir128}/{$i}. {$artist_en} - {$hs_trackname_{$i}} [128].mp3";
}
}
} 

$year = date("Y");
function MP3_Id_tags($dirfile, $singer, $track , $album, $axahang , $year)
{
$TextEncoding = 'UTF-8';
$albumPath = $axahang; // path to your image
require_once('getid3/getid3.php');
// Initialize getID3 engine
$getID3 = new getID3;
$getID3->setOption(array('encoding'=>$TextEncoding));
require_once('getid3/write.php');
// Initialize getID3 tag-writing module
$tagwriter = new getid3_writetags;
//$tagwriter->filename = '/path/to/file.mp3';
$tagwriter->filename = $dirfile;
//$tagwriter->tagformats = array('id3v1', 'id3v2.3');
$tagwriter->tagformats = array('id3v2.3');
// set various options (optional)
$tagwriter->overwrite_tags    = true;  // if true will erase existing tag data and write only passed data; if false will merge passed data with existing tag data (experimental)
$tagwriter->remove_other_tags = false; // if true removes other tag formats (e.g. ID3v1, ID3v2, APE, Lyrics3, etc) that may be present in the file and only write the specified tag format(s). If false leaves any unspecified tag formats as-is.
$tagwriter->tag_encoding      = $TextEncoding;
$tagwriter->remove_other_tags = true;
// populate data array
$TagData = array(
	'title'                  => array($track. ' [ URLSite.IR ] '),
	'artist'                 => array($singer. ' [ URLSite.IR ] '),
	'album'                  => array($album. ' [ URLSite.IR ]'),
	'year'                   => array($year),
	'genre'                  => array('[ URLSite.IR ]'),
	'comment'                => array('[ Download By [ URLSite.IR ]'),
	'track'                  => array('[ URLSite.IR ]'),
);
$fd = fopen($albumPath, 'rb');
$APICdata = fread($fd, filesize($albumPath));
fclose($fd);
if($APICdata) {
    $TagData += array(
        'attached_picture' => array(0 => array(
            'data'          => $APICdata,
            'picturetypeid' => 2,
            'description'   => 'cover',
            'mime'          => 'image/jpeg'
        ))
    );
}
$tagwriter->tag_data = $TagData;
// write tags
if ($tagwriter->WriteTags()) {
    echo 'Successfully wrote tags<br>';
    if (!empty($tagwriter->warnings)) {
        echo 'There were some warnings:<br>'.implode('<br><br>', $tagwriter->warnings);
    }
} else {
    echo 'Failed to write tags!<br>'.implode('<br><br>', $tagwriter->errors);
}
}

function Download($url, $saveto)
{
    $content = file_get_contents($url);
    file_put_contents($saveto, $content);
}
$mysrc = $_SERVER['DOCUMENT_ROOT'] . "/$dir128/$AlbumName.jpg";
Download($src,$mysrc); 

for($i=1;$i<=15;$i++) {
if(!empty($_POST['hs_link_320_'.$i.''])) {
	Download($hs_link_320_{$i}, $GenerateTrackLink_320_{$i});
	MP3_Id_tags($GenerateTrackLink_320_{$i}, $artist_en, $hs_trackname_{$i},$song_en, $mysrc, $year);
}
if(!empty($_POST['hs_link_128_'.$i.''])) {
	Download($hs_link_128_{$i}, $GenerateTrackLink_128_{$i});
	MP3_Id_tags($GenerateTrackLink_128_{$i}, $artist_en, $hs_trackname_{$i},$song_en, $mysrc, $year);
}
}

$hs_dir_320_folder = $_SERVER['DOCUMENT_ROOT']."/{$dir320}";
$hs_dir_128_folder = $_SERVER['DOCUMENT_ROOT']."/{$dir128}";

$hs_dir_320 = $_SERVER['DOCUMENT_ROOT']."/{$dir320}.zip";
$hs_dir_128 = $_SERVER['DOCUMENT_ROOT']."/{$dir128}.zip";

$zip = new ZipArchive();
$zip->open($hs_dir_320, ZipArchive::CREATE | ZipArchive::OVERWRITE);
$files = new RecursiveIteratorIterator(
    new RecursiveDirectoryIterator($hs_dir_320_folder),
    RecursiveIteratorIterator::LEAVES_ONLY
);
foreach ($files as $name => $file)
{
    if (!$file->isDir())
    {
        $filePath = $file->getRealPath();
        $relativePath = substr($filePath, strlen($hs_dir_320_folder) + 1);
        $zip->addFile($filePath, $relativePath);
    }
}
$zip->close();

$zip = new ZipArchive();
$zip->open($hs_dir_128, ZipArchive::CREATE | ZipArchive::OVERWRITE);
$files = new RecursiveIteratorIterator(
    new RecursiveDirectoryIterator($hs_dir_128_folder),
    RecursiveIteratorIterator::LEAVES_ONLY
);
foreach ($files as $name => $file)
{
    if (!$file->isDir())
    {
        $filePath = $file->getRealPath();
        $relativePath = substr($filePath, strlen($hs_dir_128_folder) + 1);
        $zip->addFile($filePath, $relativePath);
    }
}
$zip->close();
unlink($mysrc);
?>