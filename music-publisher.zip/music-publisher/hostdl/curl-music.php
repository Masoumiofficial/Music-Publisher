<?php
require_once 'jdf.php';
$dir = jdate_win('Y/m/d', time());
$dir_file="music/{$dir}";
if ( ! file_exists($dir_file))
    mkdir($dir_file, 0755, true);
 set_time_limit(0);
 
$artist_en = $_POST['artist_en'];
$song_en = $_POST['song_en'];
$link320 = $_POST['link320'];
$link128 = $_POST['link128'];
$IMG_Post = $_POST['cover'];
$src = trim($IMG_Post);

$Trackname = "{$artist_en} - {$song_en}";
$GenerateTrackLink320 = $_SERVER['DOCUMENT_ROOT'] . "/{$dir_file}/{$Trackname} (320).mp3";
$GenerateTrackLink128 = $_SERVER['DOCUMENT_ROOT'] . "/{$dir_file}/{$Trackname} (128).mp3";
function MP3_Id_tags($dirfile, $singer, $song, $axahang)
{
$TextEncoding = 'UTF-8';
$albumPath = $axahang; // path to your image
require_once('getid3/getid3.php');
// Initialize getID3 engine
$getID3 = new getID3;
$getID3->setOption(array('encoding'=>$TextEncoding));
require_once('getid3/write.php');
// Initialize getID3 tag-writing module
$tagwriter = new getid3_writetags;
//$tagwriter->filename = '/path/to/file.mp3';
$tagwriter->filename = $dirfile;
//$tagwriter->tagformats = array('id3v1', 'id3v2.3');
$tagwriter->tagformats = array('id3v2.3');
// set various options (optional)
$tagwriter->overwrite_tags    = true;  // if true will erase existing tag data and write only passed data; if false will merge passed data with existing tag data (experimental)
$tagwriter->remove_other_tags = false; // if true removes other tag formats (e.g. ID3v1, ID3v2, APE, Lyrics3, etc) that may be present in the file and only write the specified tag format(s). If false leaves any unspecified tag formats as-is.
$tagwriter->tag_encoding      = $TextEncoding;
$tagwriter->remove_other_tags = true;
// populate data array
$TagData = array(
	'title'                  => array($song. ' [ URLSite.IR ] '),
	'artist'                 => array($singer. ' [ URLSite.IR ] '),
	'album'                  => array($song. ' Single [ URLSite.IR ]'),
	'year'                   => array('2022'),
	'genre'                  => array('[ URLSite.IR ]'),
	'comment'                => array('[ Download By [ URLSite.IR ]'),
	'track'                  => array('[ URLSite.IR ]'),
);
$fd = fopen($albumPath, 'rb');
$APICdata = fread($fd, filesize($albumPath));
fclose($fd);
if($APICdata) {
    $TagData += array(
        'attached_picture' => array(0 => array(
            'data'          => $APICdata,
            'picturetypeid' => 2,
            'description'   => 'cover',
            'mime'          => 'image/jpeg'
        ))
    );
}
$tagwriter->tag_data = $TagData;
// write tags
if ($tagwriter->WriteTags()) {
    echo 'Successfully wrote tags<br>';
    if (!empty($tagwriter->warnings)) {
        echo 'There were some warnings:<br>'.implode('<br><br>', $tagwriter->warnings);
    }
} else {
    echo 'Failed to write tags!<br>'.implode('<br><br>', $tagwriter->errors);
}
} //=>end func
function Download($url, $saveto)
{
    $content = file_get_contents($url);
    file_put_contents($saveto, $content);
}
$mysrc = $_SERVER['DOCUMENT_ROOT'] . "/$dir_file/$Trackname.jpg";
Download($src,$mysrc);  
if (!empty($link320)) Download($link320, $GenerateTrackLink320);
if (!empty($link128)) Download($link128, $GenerateTrackLink128);

if (!empty($link320)) MP3_Id_tags($GenerateTrackLink320, $artist_en, $song_en, $mysrc);
if (!empty($link128)) MP3_Id_tags($GenerateTrackLink128, $artist_en, $song_en, $mysrc);


unlink($mysrc);
?>