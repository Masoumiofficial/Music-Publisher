<?php
require_once 'jdf.php';
$dir = jdate_win('Y/m/d', time());
$dir_file="music/{$dir}";
if ( ! file_exists($dir_file))
    mkdir($dir_file, 0755, true);
    set_time_limit(0);
$enname = $_POST['enname'];
$entrack = $_POST['entrack'];
$FileNames = $_POST['FileNames'];
$linkfilemp3 = $_POST['linkfilemp3'];
$linkfilemp4 = $_POST['linkfilemp4'];
$cover = $_POST['cover'];
$src = trim($cover);

$GenerateTrackLinkMp3 = $_SERVER['DOCUMENT_ROOT'] . "/$dir_file/$FileNames.mp3";
$GenerateTrackLinkMp4 = $_SERVER['DOCUMENT_ROOT'] . "/$dir_file/$FileNames.mp4";



function MP3_Id_tags($dirfile, $singer, $song, $axahang)
{
$TextEncoding = 'UTF-8';
$albumPath = $axahang; // path to your image
require_once('getid3/getid3.php');
// Initialize getID3 engine
$getID3 = new getID3;
$getID3->setOption(array('encoding'=>$TextEncoding));
require_once('getid3/write.php');
// Initialize getID3 tag-writing module
$tagwriter = new getid3_writetags;
//$tagwriter->filename = '/path/to/file.mp3';
$tagwriter->filename = $dirfile;
//$tagwriter->tagformats = array('id3v1', 'id3v2.3');
$tagwriter->tagformats = array('id3v2.3');
// set various options (optional)
$tagwriter->overwrite_tags    = true;  // if true will erase existing tag data and write only passed data; if false will merge passed data with existing tag data (experimental)
$tagwriter->remove_other_tags = false; // if true removes other tag formats (e.g. ID3v1, ID3v2, APE, Lyrics3, etc) that may be present in the file and only write the specified tag format(s). If false leaves any unspecified tag formats as-is.
$tagwriter->tag_encoding      = $TextEncoding;
$tagwriter->remove_other_tags = true;
// populate data array
$TagData = array(
	'title'                  => array($song. ' [ URLSite.IR ] '),
	'artist'                 => array($singer. ' [ URLSite.IR ] '),
	'album'                  => array($song. ' Single [ URLSite.IR ]'),
	'year'                   => array('2022'),
	'genre'                  => array('[ URLSite.IR ]'),
	'comment'                => array('[ Download By [ URLSite.IR ]'),
	'track'                  => array('[ URLSite.IR ]'),
);
$fd = fopen($albumPath, 'rb');
$APICdata = fread($fd, filesize($albumPath));
fclose($fd);
if($APICdata) {
    $TagData += array(
        'attached_picture' => array(0 => array(
            'data'          => $APICdata,
            'picturetypeid' => 2,
            'description'   => 'cover',
            'mime'          => 'image/jpeg'
        ))
    );
}
$tagwriter->tag_data = $TagData;
// write tags
if ($tagwriter->WriteTags()) {
    echo 'Successfully wrote tags<br>';
    if (!empty($tagwriter->warnings)) {
        echo 'There were some warnings:<br>'.implode('<br><br>', $tagwriter->warnings);
    }
} else {
    echo 'Failed to write tags!<br>'.implode('<br><br>', $tagwriter->errors);
}
}
function Download($url, $saveto){
	$content = file_get_contents($url);
	file_put_contents($saveto, $content);
	}

$mysrc = $_SERVER['DOCUMENT_ROOT'] . "/$dir_file/$FileNames.jpg";

Download($src,$mysrc); 
if (!empty($linkfilemp3)) Download($linkfilemp3, $GenerateTrackLinkMp3);
if (!empty($linkfilemp4)) Download($linkfilemp4, $GenerateTrackLinkMp4);
if (!empty($linkfilemp3)) MP3_Id_tags($GenerateTrackLinkMp3, $enname, $entrack, $mysrc);

?>